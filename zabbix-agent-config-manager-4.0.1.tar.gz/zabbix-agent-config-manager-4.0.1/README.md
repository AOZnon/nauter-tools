# Zabbix Agent Config Manager 4.0.1

Zabbix 8 Frontendから、対象HostのZabbix Agent 6.x設定を1項目変更してAgentを再起動するだけのFrontend Moduleです。

変更対象は次の4項目だけです。

- `Server`
- `ServerActive`
- `ListenPort`
- `Timeout`

## 構成

```text
Frontend Module
  -> Global Script (Linux / Windows)
     -> Passive Agent system.run
        -> helper
           -> Config置換/追記
           -> Agent再起動
```

成果物は次の8ファイルだけです。

```text
README.md
agent/linux/zabbix-agent-config-change
agent/windows/zabbix-agent-config-change.vbs
module/ZabbixAgentConfigManager/manifest.json
module/ZabbixAgentConfigManager/Module.php
module/ZabbixAgentConfigManager/actions/Main.php
module/ZabbixAgentConfigManager/views/zacm.view.php
module/ZabbixAgentConfigManager/assets/css/zacm.css
```

## 1. Frontend Module配置

```bash
cd /root/zabbix-agent-config-manager-4.0.1
rm -rf /usr/share/zabbix/ui/modules/ZabbixAgentConfigManager
cp -a module/ZabbixAgentConfigManager /usr/share/zabbix/ui/modules/
chown -R root:root /usr/share/zabbix/ui/modules/ZabbixAgentConfigManager
find /usr/share/zabbix/ui/modules/ZabbixAgentConfigManager -type d -exec chmod 0755 {} +
find /usr/share/zabbix/ui/modules/ZabbixAgentConfigManager -type f -exec chmod 0644 {} +
```

Zabbix UI:

```text
Administration -> General -> Modules
-> Scan directory
-> Zabbix Agent Config Manager を Enabled
```

## 2. Global Scriptを2本作成

旧`ZACM::...`、`ZACM Linux`、`ZACM Windows`が存在する場合は先に削除します。

### ZACM Linux

```text
Name: ZACM Linux
Scope: Manual host action
Type: Script
Execute on: Zabbix agent
Commands:
/usr/local/sbin/zabbix-agent-config-change '{MANUALINPUT}'
Host group: All
User group: All
Required host permissions: Write
Manual input: Enabled
Prompt: Parameter=Value
Input type: String
Default: Timeout=3
Validation rule:
^(Server|ServerActive|ListenPort|Timeout)=[A-Za-z0-9._,:;/\[\] -]{1,2048}$
```

### ZACM Windows

```text
Name: ZACM Windows
Scope: Manual host action
Type: Script
Execute on: Zabbix agent
Commands:
cscript.exe //NoLogo C:\Zabbix\zabbix-agent-config-change.vbs "{MANUALINPUT}"
Host group: All
User group: All
Required host permissions: Write
Manual input: Enabled
Prompt: Parameter=Value
Input type: String
Default: Timeout=3
Validation rule:
^(Server|ServerActive|ListenPort|Timeout)=[A-Za-z0-9._,:;/\[\] -]{1,2048}$
```

## 3. Linux Agent

```bash
install -o root -g root -m 0755 \
  agent/linux/zabbix-agent-config-change \
  /usr/local/sbin/zabbix-agent-config-change
```

AgentのメインConfigへ次の1行だけ追加します。

```text
AllowKey=system.run[/usr/local/sbin/zabbix-agent-config-change *]
```

追加後にAgentを1回再起動します。

## 4. Windows Agent

```text
C:\Zabbix\zabbix-agent-config-change.vbs
```

へhelperを配置します。

AgentのメインConfigへ次の1行だけ追加します。

```text
AllowKey=system.run[cscript.exe //NoLogo C:\Zabbix\zabbix-agent-config-change.vbs *]
```

追加後にAgentを1回再起動します。

## 5. 使用方法

Zabbix UI:

```text
Administration -> Agent config manager
```

画面は次の4項目だけです。

```text
Target host
Parameter
After
設定変更
```

実行すると、選択したParameterをAfterの値へ置換します。対象Parameterの有効行がない場合はConfig末尾へ追記します。その後Agentを再起動します。

結果表示は次だけです。

```text
OK
```

または

```text
ERROR: 理由
```

## 6. 削除

Frontend Module:

```bash
rm -rf /usr/share/zabbix/ui/modules/ZabbixAgentConfigManager
```

Linuxは `/usr/local/sbin/zabbix-agent-config-change` とAllowKey 1行を削除します。

Windowsは `C:\Zabbix\zabbix-agent-config-change.vbs` とAllowKey 1行を削除します。

Global Scriptは`ZACM Linux`と`ZACM Windows`を削除します。
