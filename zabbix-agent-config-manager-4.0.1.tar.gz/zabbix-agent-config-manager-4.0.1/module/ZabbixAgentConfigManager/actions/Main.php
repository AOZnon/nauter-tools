<?php declare(strict_types = 1);

namespace Modules\ZabbixAgentConfigManager\Actions;

use API;
use CController;
use CControllerResponseData;
use Throwable;

final class Main extends CController {
    private const PARAMETERS = ['Server', 'ServerActive', 'ListenPort', 'Timeout'];
    private const SCRIPTS = ['ZACM Linux', 'ZACM Windows'];

    protected function checkInput(): bool {
        return $this->validateInput([
            'hostid' => 'db hosts.hostid',
            'parameter' => 'in Server,ServerActive,ListenPort,Timeout',
            'new_value' => 'string',
            'change' => 'in 1'
        ]);
    }

    protected function checkPermissions(): bool {
        return true;
    }

    protected function doAction(): void {
        $hosts = API::Host()->get([
            'output' => ['hostid', 'name', 'host'],
            'filter' => ['status' => HOST_STATUS_MONITORED],
            'sortfield' => 'name'
        ]);

        $result = null;
        $hostid = (string) $this->getInput('hostid', '');
        $parameter = (string) $this->getInput('parameter', 'Timeout');
        $value = (string) $this->getInput('new_value', '');

        if ($this->hasInput('change')) {
            if ($hostid === '' || !in_array($parameter, self::PARAMETERS, true)
                    || !preg_match('/^[A-Za-z0-9._,:;\/\[\] -]{1,2048}$/D', $value)) {
                $result = 'ERROR: invalid input';
            }
            else {
                $result = $this->run((int) $hostid, $parameter.'='.$value);
            }
        }

        $this->setResponse(new CControllerResponseData([
            'hosts' => $hosts,
            'parameters' => self::PARAMETERS,
            'result' => $result,
            'input' => [
                'hostid' => $hostid,
                'parameter' => $parameter,
                'new_value' => $value
            ]
        ]));
    }

    private function run(int $hostid, string $request): string {
        $errors = [];

        foreach (self::SCRIPTS as $name) {
            $scripts = API::Script()->get([
                'output' => ['scriptid'],
                'filter' => ['name' => [$name]]
            ]);

            if (count($scripts) !== 1) {
                $errors[] = $name.': script not found';
                continue;
            }

            try {
                $response = API::Script()->execute([
                    'scriptid' => (string) $scripts[0]['scriptid'],
                    'hostid' => (string) $hostid,
                    'manualinput' => $request
                ]);
            }
            catch (Throwable $e) {
                $errors[] = $name.': '.$e->getMessage();
                continue;
            }

            if (is_array($response) && ($response['response'] ?? '') === 'success') {
                $text = trim((string) ($response['value'] ?? ''));
                return $text !== '' ? $text : 'OK';
            }

            $errors[] = $name.': '.trim((string) ($response['value'] ?? 'execution failed'));
        }

        return 'ERROR: '.implode(' / ', $errors);
    }
}
