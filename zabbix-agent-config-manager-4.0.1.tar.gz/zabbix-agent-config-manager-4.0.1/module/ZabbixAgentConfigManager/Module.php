<?php declare(strict_types = 1);

namespace Modules\ZabbixAgentConfigManager;

use APP;
use CMenuItem;
use Zabbix\Core\CModule;

final class Module extends CModule {
    public function init(): void {
        APP::Component()->get('menu.main')
            ->findOrAdd(_('Administration'))
            ->getSubmenu()
            ->add((new CMenuItem(_('Agent config manager')))->setAction('zacm.main'));
    }
}
