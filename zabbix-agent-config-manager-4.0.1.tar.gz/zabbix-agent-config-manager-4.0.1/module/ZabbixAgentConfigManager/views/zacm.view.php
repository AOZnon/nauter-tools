<?php declare(strict_types = 1);
/** @var array $data */

$page = (new CHtmlPage())->setTitle(_('Zabbix Agent Config Manager'));
$form = (new CForm('post', (new CUrl('zabbix.php'))->setArgument('action', 'zacm.main')->getUrl()))
    ->addClass('zacm-card')
    ->addItem((new CVar(CSRF_TOKEN_NAME, CCsrfTokenHelper::get('zacm.main')))->removeId());

$host_options = [];
foreach ($data['hosts'] as $host) {
    $host_options[(string) $host['hostid']] = $host['name'].' ['.$host['host'].']';
}

$parameter_options = [];
foreach ($data['parameters'] as $parameter) {
    $parameter_options[$parameter] = $parameter;
}

$selected_host = (string) ($data['input']['hostid'] ?? array_key_first($host_options) ?? '');
$selected_parameter = (string) ($data['input']['parameter'] ?? 'Timeout');
$new_value = (string) ($data['input']['new_value'] ?? '');

$form->addItem((new CFormGrid())
    ->addItem([
        new CLabel(_('Target host'), 'zacm-host'),
        new CFormField((new CSelect('hostid'))->setId('zacm-host')->setValue($selected_host)
            ->addOptions(CSelect::createOptionsFromArray($host_options)))
    ])
    ->addItem([
        new CLabel(_('Parameter'), 'zacm-parameter'),
        new CFormField((new CSelect('parameter'))->setId('zacm-parameter')->setValue($selected_parameter)
            ->addOptions(CSelect::createOptionsFromArray($parameter_options)))
    ])
    ->addItem([
        new CLabel(_('After'), 'zacm-new-value'),
        new CFormField((new CTextBox('new_value', $new_value))->setId('zacm-new-value'))
    ]));

$form->addItem((new CFormActions())
    ->addItem((new CButton('change', _('設定変更')))
        ->addClass('zacm-submit')
        ->setAttribute('value', '1')
        ->setAttribute('type', 'submit')));

$page->addItem($form);

if ($data['result'] !== null) {
    $result = (string) $data['result'];
    $class = strncmp($result, 'ERROR:', 6) === 0
        ? 'zacm-result zacm-result-error'
        : 'zacm-result zacm-result-ok';

    $page->addItem((new CTag('pre', true,
        htmlspecialchars($result, ENT_QUOTES, 'UTF-8')))->addClass($class));
}

$page->show();
