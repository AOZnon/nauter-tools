Option Explicit

Const ForReading = 1
Const ForWriting = 2

Dim fso, sh, request, p, parameter, value, wmi, services, item, svc
Dim pathName, exePath, confPath, re, m, exeDir, tmpPath, src, tmp, line, found, allText, dst, cmd

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")

Sub Fail(message)
  WScript.Echo "ERROR: " & message
  WScript.Quit 0
End Sub

If WScript.Arguments.Count = 0 Then Fail "invalid parameter"
request = WScript.Arguments(0)
p = InStr(request, "=")
If p = 0 Then Fail "invalid parameter"
parameter = Left(request, p - 1)
value = Mid(request, p + 1)
If Len(value) = 0 Then Fail "empty value"

Select Case parameter
  Case "Server", "ServerActive", "ListenPort", "Timeout"
  Case Else
    Fail "invalid parameter"
End Select

Set wmi = GetObject("winmgmts:\\.\root\cimv2")
Set services = wmi.ExecQuery("Select Name,PathName,ProcessId from Win32_Service where ProcessId<>0")
Set svc = Nothing
For Each item In services
  pathName = LCase(CStr(item.PathName))
  If InStr(pathName, "zabbix_agentd.exe") > 0 Or InStr(pathName, "zabbix_agent2.exe") > 0 Then
    Set svc = item
    Exit For
  End If
Next
If svc Is Nothing Then Fail "Zabbix Agent service not found"

pathName = CStr(svc.PathName)
Set re = New RegExp
re.IgnoreCase = True
re.Global = False
re.Pattern = "^\s*""([^""]+\.exe)"""
If re.Test(pathName) Then
  Set m = re.Execute(pathName)(0)
  exePath = m.SubMatches(0)
Else
  re.Pattern = "^\s*([^ ]+\.exe)"
  If Not re.Test(pathName) Then Fail "Zabbix Agent executable not found"
  Set m = re.Execute(pathName)(0)
  exePath = m.SubMatches(0)
End If

re.Pattern = "(-c|--config)(=|[ \t]+)(""([^""]+)""|([^ \t]+))"
If re.Test(pathName) Then
  Set m = re.Execute(pathName)(0)
  If Len(m.SubMatches(3)) > 0 Then
    confPath = m.SubMatches(3)
  Else
    confPath = m.SubMatches(4)
  End If
Else
  exeDir = fso.GetParentFolderName(exePath)
  If InStr(LCase(pathName), "zabbix_agent2.exe") > 0 Then
    confPath = exeDir & "\zabbix_agent2.conf"
  ElseIf fso.FileExists(exeDir & "\zabbix_agentd.conf") Then
    confPath = exeDir & "\zabbix_agentd.conf"
  Else
    confPath = "C:\zabbix_agentd.conf"
  End If
End If
If Not fso.FileExists(confPath) Then Fail "Config file not found: " & confPath

tmpPath = fso.GetParentFolderName(confPath) & "\" & fso.GetTempName
Set re = New RegExp
re.IgnoreCase = False
re.Global = False
re.Pattern = "^[ \t]*" & parameter & "[ \t]*="

Set src = fso.OpenTextFile(confPath, ForReading, False)
Set tmp = fso.CreateTextFile(tmpPath, True, False)
found = False
Do Until src.AtEndOfStream
  line = src.ReadLine
  If re.Test(line) Then
    tmp.WriteLine parameter & "=" & value
    found = True
  Else
    tmp.WriteLine line
  End If
Loop
If Not found Then tmp.WriteLine parameter & "=" & value
src.Close
tmp.Close

Set src = fso.OpenTextFile(tmpPath, ForReading, False)
allText = src.ReadAll
src.Close
Set dst = fso.OpenTextFile(confPath, ForWriting, False)
dst.Write allText
dst.Close
fso.DeleteFile tmpPath, True

cmd = "cmd.exe /c ping 127.0.0.1 -n 3 >nul & sc stop """ & svc.Name & """ >nul 2>&1 & sc start """ & svc.Name & """ >nul 2>&1"
sh.Run cmd, 0, False

WScript.Echo "OK"
