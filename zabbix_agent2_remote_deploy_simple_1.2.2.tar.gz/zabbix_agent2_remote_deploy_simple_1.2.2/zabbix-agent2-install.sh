#!/bin/bash

if [[ "${ZBX_ASKPASS_MODE:-}" == 1 ]]; then
    printf '%s\n' "${ZBX_DEPLOY_PASSWORD:-}"
    exit
fi

TARGET="${1:-}"
USERNAME="${2:-}"
IFS= read -r PASSWORD || true
export ZBX_DEPLOY_PASSWORD="$PASSWORD" ZBX_ASKPASS_MODE=1 SSH_ASKPASS="$0" DISPLAY=:0

SSH_OPTS=(
    -T
    -o StrictHostKeyChecking=no
    -o UserKnownHostsFile=/dev/null
    -o PreferredAuthentications=password
    -o PubkeyAuthentication=no
    -o NumberOfPasswordPrompts=1
    -o ConnectTimeout=10
    -o LogLevel=ERROR
    -o ControlMaster=no
)
DEST="${USERNAME}@${TARGET}"

MAJOR="$(setsid -w ssh "${SSH_OPTS[@]}" "$DEST" '. /etc/os-release 2>/dev/null; printf "%s" "${VERSION_ID%%.*}"' 2>/dev/null)"
[[ -n "$MAJOR" ]] || { echo 'ERROR: SSH connection failed.'; exit 1; }

MODULE="/usr/local/zabbix/RHEL${MAJOR}.tar"
[[ -f "$MODULE" ]] || { echo "ERROR: ${MODULE} not found."; exit 1; }

REMOTE_MODULE="/tmp/zabbix-agent2-${RANDOM}${RANDOM}.tar"
setsid -w ssh "${SSH_OPTS[@]}" "$DEST" \
    "cat > '$REMOTE_MODULE' || { rm -f '$REMOTE_MODULE'; exit 1; }" < "$MODULE" \
    || { echo 'ERROR: Module transfer failed.'; exit 1; }

RESULT="$({
    printf '%s\n' "$PASSWORD"
    cat <<'REMOTE'
MODULE="$1"
WORK="$(mktemp -d /tmp/zabbix-agent2.XXXXXX)" || { echo 'ERROR: Temporary directory creation failed.'; exit 1; }
trap 'rm -rf "$WORK"' EXIT

tar -xf "$MODULE" -C "$WORK" >/dev/null 2>&1 || { echo 'ERROR: Module extraction failed.'; exit 1; }
mapfile -t RPMS < <(find "$WORK" -type f \( -name 'zabbix-agent2-*.rpm' -o -name 'zabbix-agent2-plugin-*.rpm' \))
[[ ${#RPMS[@]} -gt 0 ]] || { echo 'ERROR: Agent2 RPM not found.'; exit 1; }
CONF="$(find "$WORK" -type f -name zabbix_agent2.conf -print -quit)"
[[ -n "$CONF" ]] || { echo 'ERROR: zabbix_agent2.conf not found.'; exit 1; }

dnf install -y "${RPMS[@]}" >/dev/null 2>&1 || { echo 'ERROR: RPM installation failed.'; exit 1; }
install -m 0644 "$CONF" /etc/zabbix/zabbix_agent2.conf || { echo 'ERROR: Config installation failed.'; exit 1; }
mkdir -p /etc/systemd/system/zabbix-agent2.service.d
printf '[Service]\nUser=root\nGroup=root\n' > /etc/systemd/system/zabbix-agent2.service.d/override.conf
systemctl daemon-reload >/dev/null 2>&1 || { echo 'ERROR: systemd reload failed.'; exit 1; }
systemctl enable --now zabbix-agent2 >/dev/null 2>&1 || { echo 'ERROR: Agent2 service start failed.'; exit 1; }
echo 'SUCCESS: Zabbix Agent2 installed.'
REMOTE
} | setsid -w ssh "${SSH_OPTS[@]}" "$DEST" \
    "trap 'rm -f \"$REMOTE_MODULE\"' EXIT; sudo -S -p '' bash -s -- '$REMOTE_MODULE'" 2>&1)"
RC=$?
unset ZBX_DEPLOY_PASSWORD PASSWORD

if [[ $RC -ne 0 ]]; then
    ERROR="$(printf '%s\n' "$RESULT" | grep -E '^(ERROR:|sudo:)' | tail -n 1)"
    echo "${ERROR:-ERROR: Installation failed.}"
    exit 1
fi

printf '%s\n' "$RESULT" | grep -E '^(SUCCESS:|ERROR:)' | tail -n 1
