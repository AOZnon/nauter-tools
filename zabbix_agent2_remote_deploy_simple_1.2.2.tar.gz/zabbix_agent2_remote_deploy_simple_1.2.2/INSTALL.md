# Agent2 Deployment 導入手順

Zabbix Server / Frontendが同一ホストにある環境向けの最小構成です。
常駐サービス、API、Job、履歴、Precheck、テスト、アンインストール機能はありません。

## 1. インストールスクリプトを配置

Zabbix Serverホストで実行します。

```bash
mkdir -p /usr/local/zabbix
cp zabbix-agent2-install.sh /usr/local/zabbix/zabbix-agent2-install.sh
chmod 0755 /usr/local/zabbix/zabbix-agent2-install.sh
```

この機能はOS標準の`ssh`と`setsid`を使用します。成果物からパッケージ追加は行いません。

## 2. Agent2モジュールを配置

RHEL 9用：

```bash
cp RHEL9.tar /usr/local/zabbix/RHEL9.tar
chmod 0644 /usr/local/zabbix/RHEL9.tar
```

RHEL 10なら`RHEL10.tar`です。

モジュールには以下を格納します。

```text
zabbix-agent2-*.x86_64.rpm
zabbix-agent2-plugin-*.x86_64.rpm
zabbix_agent2.conf
```

実行時はこのtarをTargetの`/tmp/zabbix-agent2-*.tar`へ転送します。`dnf install`には、このtarを`/tmp`配下へ展開して得たAgent2/Plugin RPMのローカルファイルパスだけを指定します。Agent2 RPMをRepository名で指定して取得する処理はありません。

## 3. Frontend Moduleを配置

```bash
cp -a frontend_module/agent2_deployment /usr/share/zabbix/modules/
chown -R root:root /usr/share/zabbix/modules/agent2_deployment
```

## 4. Zabbix UIでModuleを有効化

```text
Administration
→ General
→ Modules
→ Scan directory
→ Agent2 Deployment
→ Enable
```

`Monitoring → Agent2 Deployment`を開き、以下を入力します。

- Target Host
- Username
- Password

`Install`を押すと同期実行します。

成功時：

```text
SUCCESS: Zabbix Agent2 installed.
```

失敗時は理由を1行だけ表示します。

```text
ERROR: RPM installation failed.
```

Targetへ転送した`/tmp/zabbix-agent2-*.tar`と展開用`/tmp/zabbix-agent2.*`は、成功・失敗に関係なく処理終了時に削除します。SSHはControlMasterを使用せず、各SSHコマンド終了時に接続も終了します。
