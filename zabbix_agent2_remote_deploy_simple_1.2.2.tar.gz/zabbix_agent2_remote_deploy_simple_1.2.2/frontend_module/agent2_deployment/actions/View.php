<?php
namespace Modules\Agent2Deployment\Actions;

class View extends \CController {
    protected function init(): void {
        $this->disableSIDvalidation();
    }

    protected function checkInput(): bool {
        return true;
    }

    protected function checkPermissions(): bool {
        return $this->getUserType() == USER_TYPE_SUPER_ADMIN;
    }

    protected function doAction(): void {
        $data = ['target' => '', 'username' => '', 'result' => ''];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data['target'] = trim((string) ($_POST['target'] ?? ''));
            $data['username'] = trim((string) ($_POST['username'] ?? ''));
            $password = (string) ($_POST['password'] ?? '');
            set_time_limit(600);

            $process = proc_open(
                '/usr/local/zabbix/zabbix-agent2-install.sh '.escapeshellarg($data['target']).' '.escapeshellarg($data['username']),
                [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['redirect', 1]],
                $pipes
            );

            if (is_resource($process)) {
                fwrite($pipes[0], $password."\n");
                fclose($pipes[0]);
                $data['result'] = trim(stream_get_contents($pipes[1]));
                fclose($pipes[1]);
                $rc = proc_close($process);
                $data['result'] = $data['result'] !== '' ? $data['result'] : ($rc === 0 ? 'SUCCESS: Completed.' : 'ERROR: Installation failed.');
            }
            else {
                $data['result'] = 'ERROR: Installer could not be started.';
            }
        }

        $response = new \CControllerResponseData($data);
        $response->setTitle(_('Agent2 Deployment'));
        $this->setResponse($response);
    }
}
