<?php
namespace Modules\Agent2Deployment;

use APP;

class Module extends \Core\CModule {
    public function init(): void {
        APP::Component()->get('menu.main')
            ->findOrAdd(_('Monitoring'))
            ->getSubmenu()
            ->add((new \CMenuItem(_('Agent2 Deployment')))
                ->setAction('agent2deploy.view'));
    }
}
