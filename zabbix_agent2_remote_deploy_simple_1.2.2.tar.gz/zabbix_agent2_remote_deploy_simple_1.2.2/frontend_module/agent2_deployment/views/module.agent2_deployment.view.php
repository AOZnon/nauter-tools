<?php
$style = new CTag('style', true, '
.agent2-card{max-width:560px;padding:20px;border:1px solid #d0d7de;border-radius:6px;background:#fff;box-shadow:0 1px 0 rgba(27,31,36,.04)}
.agent2-field{margin-bottom:16px}.agent2-field label{display:block;margin-bottom:6px;font-weight:600;color:#1f2328}
.agent2-input{width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid #d0d7de;border-radius:6px;background:#fff;color:#1f2328}
.agent2-button{padding:7px 16px;border:1px solid rgba(27,31,36,.15);border-radius:6px;background:#1f883d;color:#fff;font-weight:600;cursor:pointer}
.agent2-result{margin-top:16px;padding:10px 12px;border:1px solid;border-radius:6px;color:#1f2328}
.agent2-success{border-color:#1a7f37;background:#dafbe1}.agent2-error{border-color:#cf222e;background:#ffebe9}
');

$target = (new CInput('text', 'target', $data['target']))->addClass('agent2-input');
$username = (new CInput('text', 'username', $data['username']))->addClass('agent2-input');
$password = (new CInput('password', 'password', ''))->addClass('agent2-input');

$form = (new CTag('form', true, [
    (new CDiv([new CTag('label', true, _('Target Host')), $target]))->addClass('agent2-field'),
    (new CDiv([new CTag('label', true, _('Username')), $username]))->addClass('agent2-field'),
    (new CDiv([new CTag('label', true, _('Password')), $password]))->addClass('agent2-field'),
    (new CInput('submit', 'install', _('Install')))->addClass('agent2-button')
]))
    ->setAttribute('method', 'post')
    ->setAttribute('action', 'zabbix.php?action=agent2deploy.view');

$items = [$style, $form];
if ($data['result'] !== '') {
    $result = (new CDiv($data['result']))->addClass('agent2-result');
    $result->addClass(strpos($data['result'], 'SUCCESS:') === 0 ? 'agent2-success' : 'agent2-error');
    $items[] = $result;
}

(new CWidget())
    ->setTitle(_('Agent2 Deployment'))
    ->addItem((new CDiv($items))->addClass('agent2-card'))
    ->show();
